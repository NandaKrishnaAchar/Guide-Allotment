from flask import Flask,render_template,request,flash,redirect,url_for
from datetime import datetime
import json
import csv

with open('config.json','r') as c:
    params=json.load(c)["params"]

app = Flask(__name__)
@app.route('/',methods=['GET','POST'])
def home():
    if (request.method == 'POST'):
        usn = request.form.get('usn')
        password = request.form.get('pass')
        usn=usn.lower()
        flag = [0, 0]
        data = []
        with open('usn.csv') as f:
            r = csv.reader(f)
            next(r)
            for row in r:
                data.append(row)
        for i in data:
            if (usn == i[0]):
                flag[0] = 1
                if (password == i[1]):
                    flag[1] = 1
                else:
                    break
        if (flag[0] == 0):
            print("USN number Error")
        elif (flag[1] == 0):
            print("Password Error")
        else:
            print("Successfully signed up")
    return render_template('index.html',params=params)

if __name__=="__main__":
     app.run(port=5000, debug=True)