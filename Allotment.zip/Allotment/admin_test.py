from flask import Flask,render_template,request,flash,redirect,url_for
from flask_sqlalchemy import SQLAlchemy
from flask_mail import Mail
from datetime import datetime
import json

with open('config.json','r') as c:
    params=json.load(c)["params"]

app = Flask(__name__)
app.secret_key = b'_5#y2L"F4Q8z\n\xec]/'

if(params['local_server']):
    app.config['SQLALCHEMY_DATABASE_URI'] = params['local_uri']
else:
    app.config['SQLALCHEMY_DATABASE_URI'] = params['prod_uri']
db = SQLAlchemy(app)

class student(db.Model):
    USN= db.Column(db.String(30), primary_key=True)
    Name = db.Column(db.String(30), unique=False,nullable=False)
    Alloted_Faculty = db.Column(db.String(50), unique=True,nullable=False)

post = student.query.all()

for i in post:
    print(i.USN,end=" ")
    print(i.Name,end=" ")
    print(i.Alloted_Faculty)
