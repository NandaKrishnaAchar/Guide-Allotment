import random
mentor_status=[ 2 for item in range(29)]


preference={}

for i in range(51):
    if(i<10):
        preference["01JST17CS00" + str(i)] = str(random.randint(0, 28))+","+str(random.randint(0, 28))+","+str(random.randint(0, 28))+","+str(random.randint(0, 28))
    else:
        preference["01JST17CS0" + str(i)] = str(random.randint(0, 28)) + "," + str(random.randint(0, 28)) + "," + str(
            random.randint(0, 28)) + ","+str(random.randint(0, 28))
#print(preference)

alloted={}
for key,value in preference.items():
    preference_list=value.split(",")
    for i in preference_list:
        if(mentor_status[int(i)]>0):
            alloted[key]=i
            mentor_status[int(i)]-=1
            break
    else:
        alloted[key]="NULL"
cnt=0
for key,value in alloted.items():
    print(f"{key} : {value}",end=" Requested :  ")
    if(cnt<10):
        print(preference["01JST17CS00"+str(cnt)])
    else:
        print(preference["01JST17CS0" + str(cnt)])
    cnt+=1


